package main

import vista.ClienteVista

fun main() {
    val vista = ClienteVista()
    vista.iniciar()
}
