package modelo

class ClienteModelo {
    private val clientes = mutableListOf(
        listOf<Any>("Diana Laura", "52125212", 1500.0),
        listOf<Any>("Montserrat Alvarez", "4542522", 10000.0),
        listOf<Any>("Javier Flores", "74832902", 2000.0),
        listOf<Any>("Alexis Hernandez", "98765432", 120000.0),
        listOf<Any>("Jordi España", "12345678", 550000.0),
        listOf<Any>("Lily Fox", "45678901", 15000000.0),
        listOf<Any>("Abella Danger", "32165498", 3000000.0),
        listOf<Any>("Lana Rhoades", "65478912", 7000000.0),
        listOf<Any>("Yannet Garcia", "85274196", 80000.0),
        listOf<Any>("Karely Ruiz", "96385274", 900000.0)
    )

    fun listarClientes(): List<List<Any>> {
        return clientes
    }

    fun buscarCliente(numeroCuenta: String): List<Any>? {
        return clientes.find { it[1] == numeroCuenta }
            val cliente = modelo.buscarCliente(numeroCuenta)
            if (cliente != null) {
                v.mostrarMensaje("Bienvenido ${cliente[0]} --- Saldo: ${cliente[2]}")
            } else {
                v.mostrarMensaje("Cliente no encontrado.")
            }
        }
    }

    fun retirar(numeroCuenta: String, cantidad: Double): String {
        val cliente = buscarCliente(numeroCuenta)
        return if (cliente != null && cantidad <= cliente[2].toString().toDouble()) {
            val nuevoSaldo = cliente[2].toString().toDouble() - cantidad
            actualizarSaldo(cliente, nuevoSaldo)
            "Retiro de $$cantidad realizado exitosamente. Saldo actual: $$nuevoSaldo"
        } else {
            "Fondos insuficientes o cuenta no encontrada."
        }
    }

    fun depositar(numeroCuenta: String, cantidad: Double): String {
        val cliente = buscarCliente(numeroCuenta)
        return if (cliente != null) {
            val nuevoSaldo = cliente[2].toString().toDouble() + cantidad
            actualizarSaldo(cliente, nuevoSaldo)
            "Depósito de $$cantidad realizado exitosamente. Saldo actual: $$nuevoSaldo"
        } else {
            "Cuenta no encontrada."
        }
    }

    private fun actualizarSaldo(cliente: List<Any>, nuevoSaldo: Double) {
        val indice = clientes.indexOf(cliente)
        clientes[indice] = listOf(cliente[0], cliente[1], nuevoSaldo)
    }
}
