package vista

interface InterfaceCliente {
    fun mostrarMenu()
    fun iniciar()
    fun mostrarClientes(clientes: List<List<Any>>)
    fun mostrarMensaje(mensaje: String)
}
