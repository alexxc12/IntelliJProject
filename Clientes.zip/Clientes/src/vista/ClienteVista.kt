package vista

import presentador.ClientePresentador

class ClienteVista : InterfaceCliente {

    val P = ClientePresentador(v = this)

    override fun mostrarMenu() {
        println("\n----Menú----")
        println("1. Listar Clientes")
        println("2. Buscar número de cuenta")
        println("3. Realizar Retiro")
        println("4. Hacer Depósito")
        println("5. Salir")
    }

    override fun iniciar() {
        var opcion: Int
        do {
            mostrarMenu()
            opcion = readln().toInt()

            when (opcion) {
                1 -> P.listarClientes()
                2 -> {
                    val numeroCuenta = solicitarNumeroCuenta()
                    P.buscarCliente(numeroCuenta)
                }
                3 -> {
                    val numeroCuenta = solicitarNumeroCuenta()
                    val cantidad = solicitarRetiro()
                    println(P.hacerRetiro(numeroCuenta, cantidad))
                }
                4 -> {
                    val numeroCuenta = solicitarNumeroCuenta()
                    val cantidad = solicitarDeposito()
                    println(P.hacerDeposito(numeroCuenta, cantidad))
                }
                5 -> println("Saliendo del programa...")
                else -> println("Opción inválida. Intente de nuevo.")
            }
        } while (opcion != 5)
    }

    private fun solicitarNumeroCuenta(): String {
        println("Ingrese el número de cuenta:")
        return readln()
    }

    private fun solicitarRetiro(): Double {
        println("Ingrese el monto a retirar:")
        return readln().toDouble()
    }

    private fun solicitarDeposito(): Double {
        println("Ingrese el monto a depositar:")
        return readln().toDouble()
    }

    override fun mostrarClientes(clientes: List<List<Any>>) {
        for (cliente in clientes) {
            println("Cliente: ${cliente[0]} --- Cuenta: ${cliente[1]} --- Saldo: ${cliente[2]}")
        }
    }

    override fun mostrarMensaje(mensaje: String) {
        println(mensaje)
    }
}
