package presentador
import modelo.ClienteModelo
import vista.InterfaceCliente

class ClientePresentador(val v: InterfaceCliente) {

    private val modelo = ClienteModelo()

    fun listarClientes() {
        val clientes = modelo.listarClientes()
        v.mostrarClientes(clientes)
    }

    fun hacerRetiro(numeroCuenta: String, cantidad: Double): String {
        return modelo.retirar(numeroCuenta, cantidad)
    }

    fun hacerDeposito(numeroCuenta: String, cantidad: Double): String {
        return modelo.depositar(numeroCuenta, cantidad)
    }
}
