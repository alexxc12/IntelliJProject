package Presentador

import Modelo.ModeloAreasFiguras
import Vista.CalculadoraInterface
import Vista.InterfaceFiguras

class PresentadorAreasFiguras ( val V: InterfaceFiguras) {
    val M = ModeloAreasFiguras()

    fun calcularAreaCuadrado(lado:Double){
        V.mostrarAreaCuadrado(M.calcularAreaCuadrado(lado))
    }

    fun calcularAreaRectangulo(largo:Double, base:Double){
        V.mostrarAreaRectangulo(M.calcularAreaRectangulo(largo, base))
    }
    fun calcularAreaTriangulo(base:Double, altura:Double){
        V.mostrarAreaTriangulo(M.calcularAreaTriangulo(base, altura))
    }
    fun calcularAreaTrapecio(baseMayor:Double, baseMenor:Double, altura:Double){
        V.mostrarAreaTrapecio(M.calcularAreaTrapecio(baseMayor, baseMenor, altura))
    }
}