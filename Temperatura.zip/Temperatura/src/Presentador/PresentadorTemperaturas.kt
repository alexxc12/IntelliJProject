package Presentador

import Modelo.ModeloTemperaturas
import Vista.CalculadoraInterface

class PresentadorTemperaturas (val V: CalculadoraInterface) {

    val modelo = ModeloTemperaturas()

    fun convertirFahrenheitACelsius(fahrenheit: Double){
        val result=modelo.convertirFahrenheitACelsius(fahrenheit)
        V.mostrarGradosCelcius(result)
    }
    fun convertirCelsiusAKelvin(celsius: Double){
        val result=modelo.convertirCelsiusAKelvin(celsius)
        V.mostrarGradosK(result)
    }

    fun convertirCelsiusAFahrenheit(celsius: Double){
        val result=modelo.convertirFahrenheitACelsius(celsius)
        V.mostrarGradosF(result)
    }
}