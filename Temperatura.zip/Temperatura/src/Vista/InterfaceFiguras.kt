package Vista

interface InterfaceFiguras {
    fun menu()

    fun mostrarAreaCuadrado(area: Double)
    fun mostrarAreaRectangulo(area: Double)
    fun mostrarAreaTrapecio(area: Double)
    fun mostrarAreaTriangulo(area: Double)
}