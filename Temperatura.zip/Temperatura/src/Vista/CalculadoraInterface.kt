package Vista

interface CalculadoraInterface {
        fun menu()

        fun mostrarGradosCelcius(r:Double)
        fun mostrarGradosF(r:Double)
        fun mostrarGradosK(r:Double)
}