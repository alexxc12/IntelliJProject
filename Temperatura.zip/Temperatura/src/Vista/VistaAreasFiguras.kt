package Vista

import Presentador.PresentadorAreasFiguras

class VistaAreasFiguras : InterfaceFiguras {

    val P = PresentadorAreasFiguras(this)

    override fun menu() {
        println("Elige la figura geométrica:")
        println("1 - Cuadrado")
        println("2 - Rectángulo")
        println("3 - Triángulo")
        println("4 - Trapecio")

        when (readln().toInt()) {
            1 -> {
                println("Ingrese el lado:")
                val lado = readln().toDouble()
                P.calcularAreaCuadrado(lado)
            }
            2 -> {
                println("Ingrese el largo:")
                val largo = readln().toDouble()
                println("Ingrese el ancho:")
                val ancho = readln().toDouble()
                P.calcularAreaRectangulo(largo, ancho)
            }
            3 -> {
                println("Ingrese la base:")
                val base = readln().toDouble()
                println("Ingrese la altura:")
                val altura = readln().toDouble()
                P.calcularAreaTriangulo(base, altura)
            }
            4 -> {
                println("Ingrese la base mayor:")
                val baseMayor = readln().toDouble()
                println("Ingrese la base menor:")
                val baseMenor = readln().toDouble()
                println("Ingrese la altura:")
                val altura = readln().toDouble()
                P.calcularAreaTrapecio(baseMayor, baseMenor, altura)
            }
            else -> {
                println("Opción inválida")
            }
        }
    }

    override fun mostrarAreaCuadrado(area: Double) {
        println("El área de la figura es: $area")
    }

    override fun mostrarAreaRectangulo(area: Double) {
        println("El área de la figura es: $area")
    }

    override fun mostrarAreaTrapecio(area: Double) {
        println("El área de la figura es: $area")
    }

    override fun mostrarAreaTriangulo(area: Double) {
        println("El área de la figura es: $area")
    }
}