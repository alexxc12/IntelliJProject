package Vista

import Presentador.PresentadorTemperaturas

class VistaTemperaturas : CalculadoraInterface {

    //Interactu con el usuario
    //Datos de entrada
    //Datos de salida
    val P  = PresentadorTemperaturas (this)

    override fun menu() {
        println("Elige la conversión:")
        println("1 - Celsius a Fahrenheit")
        println("2 - Fahrenheit a Celsius")
        println("3 - Celsius a Kelvin")

        when(readln().toInt()){
            1-> {
                println("Ingrese la temperatura en Celsius:")
                val celsius = readln().toDouble()
                 P.convertirCelsiusAFahrenheit(celsius)
            }
            2-> {
                println("Ingrese la temperatura en Fahrenheit:")
                val fahrenheit = readln().toDouble()
                P.convertirFahrenheitACelsius(fahrenheit)
            }
            3-> {
                println("Ingrese la temperatura en Celsius:")
                val celsius = readln().toDouble()
                P.convertirCelsiusAKelvin(celsius)
            }
            else -> {
                println("Opción inválida")
            }
        }
    }

    override fun mostrarGradosCelcius(r: Double) {
        println("Resultado de la conversión es: $r")
    }

    override fun mostrarGradosF(r: Double) {
        println("Resultado de la conversión es: $r")
    }

    override fun mostrarGradosK(r: Double) {
        println("Resultado de la conversión es: $r")
    }


}