import Vista.VistaTemperaturas
import Vista.VistaAreasFiguras

fun main() {
    do {
        println("Elige una opción:")
        println("1 - Conversión de Temperaturas")
        println("2 - Cálculo de Áreas de Figuras")
        println("3 - Salir")

        val opcion = readln().toInt()

        when (opcion) {
            1 -> VistaTemperaturas().menu()
            2 -> VistaAreasFiguras().menu()
            else -> {
                println("Opción inválida")
                return
            }
        }
    }while (opcion != 3)
}