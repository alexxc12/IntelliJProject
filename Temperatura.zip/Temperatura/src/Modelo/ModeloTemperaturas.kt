package Modelo

import Vista.CalculadoraInterface

class ModeloTemperaturas : CalculadoraInterface {

    fun convertirCelsiusAFahrenheit(celsius: Double): Double {
        return (celsius * 9 / 5) + 32
    }

    fun convertirFahrenheitACelsius(fahrenheit: Double): Double {
        return (fahrenheit - 32) * 5 / 9
    }

    fun convertirCelsiusAKelvin(celsius: Double): Double {
        return celsius + 273.15
    }

    override fun menu() {
        TODO("Not yet implemented")
    }

    override fun mostrarResultado(r: Double) {
        TODO("Not yet implemented")
    }
}