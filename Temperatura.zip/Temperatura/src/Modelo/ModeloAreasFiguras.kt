package Modelo

import Vista.CalculadoraInterface

class ModeloAreasFiguras  {
    fun calcularAreaCuadrado(lado: Double): Double {
        return lado * lado
    }

    fun calcularAreaRectangulo(largo: Double, ancho: Double): Double {
        return largo * ancho
    }

    fun calcularAreaTriangulo(base: Double, altura: Double): Double {
        return (base * altura) / 2
    }

    fun calcularAreaTrapecio(baseMayor: Double, baseMenor: Double, altura: Double): Double {
        return ((baseMayor + baseMenor) / 2) * altura
    }
}