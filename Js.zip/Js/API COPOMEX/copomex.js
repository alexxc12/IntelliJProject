document.getElementById('postalCodeForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const postalCode = document.getElementById('postalCode').value;
    const token = 'YOUR_API_TOKEN';  // Reemplaza con tu token
    const url = `https://api.copomex.com/query/get_colonia_por_cp/${postalCode}?token=${token}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                displayError(data.error_message);
            } else {
                displayResults(data.response.colonias);
            }
        })
        .catch(error => {
            displayError("Hubo un error al realizar la consulta.");
            console.error(error);
        });
});

function displayResults(colonias) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '<h2>Colonias Encontradas:</h2>';
    const list = document.createElement('ul');
    
    colonias.forEach(colonia => {
        const listItem = document.createElement('li');
        listItem.textContent = colonia;
        list.appendChild(listItem);
    });
    
    resultsDiv.appendChild(list);
}

function displayError(message) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = `<p class="error">${message}</p>`;
}
