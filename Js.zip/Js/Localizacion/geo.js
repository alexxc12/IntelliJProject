if(navigator.geolocation){
    console.log("Podemos obtener la ubicación")
    const Fsuccess=(position)=>{
        console.log(position)
        const latitude=position.coords.latitude
        const longitude=position.coords.longitude
        const enlace=document.getElementById("enlace")
        const enlace2=document.getElementById("enlace2")
        enlace.href=`https://www.google.com/maps/place/Mamitas+Club+Puebla/@19.0120763,-98.1927893,17z/data=!3m1!4b1!4m6!3m5!1s0x85cfc09c9e9b4e4b:0x10efcd3051fad88b!8m2!3d19.0120712!4d-98.1902144!16s%2Fg%2F11cs1wj_xd?entry=ttu&g_ep=EgoyMDI0MTAwMS4wIKXMDSoASAFQAw%3D%3D${latitude}/${longitude}`
        enlace2.href=`https://www.openstreetmap.org/search?query=hong%20kong%20Tijuana#map=19/32.537281/-117.039926${latitude}/${longitude}`
        console.log(`Tu ubicacion es ${latitude} ${longitude}`)
    }
    const Ferror=()=>{
        console.log("Error al obtener la ubicación")
        const enlace=document.getElementById("enlace")
        enlace.href="https://www.google.com/maps"
        console.log("No se pudo obtener la ubicación")
    }
    const option={
        enableHighAccuracy:true,
        timeout:5000,
        maximumAge:0
    }
    navigator.geolocation.getCurrentPosition(Fsuccess,Ferror,option)
}else{
    console.log("El navegador no tiene la funcionalidad de obtener la ubicación.")
}
